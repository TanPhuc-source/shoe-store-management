import React, { createContext, useState, useEffect } from 'react';
import { getCategories, getBrands } from '../services/productService';

export const FilterContext = createContext();

export function FilterProvider({ children }) {
  const [filters, setFilters] = useState({
    name: '',
    categoryIds: [],
    brandIds: [],
    minPrice: '',
    maxPrice: '',
    status: '',
    sizeIds: [],
    color: '',
    categories: [],
    brands: [],
  });

  useEffect(() => {
    const fetchFilters = async () => {
      try {
        const [catResponse, brandResponse] = await Promise.all([
          getCategories(),
          getBrands(),
        ]);
        setFilters((prev) => ({
          ...prev,
          categories: catResponse.data,
          brands: brandResponse.data,
        }));
      } catch (error) {
        console.error('Lỗi khi lấy bộ lọc:', error);
      }
    };
    fetchFilters();
  }, []);

  const handleFilterChange = (e) => {
    const { name, value, type, checked } = e.target;
    if (type === 'checkbox') {
      const filterArray = name === 'categoryIds' ? [...filters.categoryIds] :
        name === 'brandIds' ? [...filters.brandIds] : [...filters.sizeIds];
      if (checked) {
        filterArray.push(value);
      } else {
        const index = filterArray.indexOf(value);
        if (index > -1) filterArray.splice(index, 1);
      }
      setFilters({ ...filters, [name]: filterArray });
    } else {
      setFilters({ ...filters, [name]: value });
    }
  };

  const handleResetFilters = () => {
    setFilters({
      name: '',
      categoryIds: [],
      brandIds: [],
      minPrice: '',
      maxPrice: '',
      status: '',
      sizeIds: [],
      color: '',
      categories: filters.categories,
      brands: filters.brands,
    });
  };

  return (
    <FilterContext.Provider value={{ filters, handleFilterChange, handleResetFilters }}>
      {children}
    </FilterContext.Provider>
  );
}