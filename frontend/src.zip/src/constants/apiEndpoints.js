export const API_ENDPOINTS = {
    PRODUCTS: '/api/products',
    PRODUCT_DETAIL: (id) => `/api/products/${id}`,
    CART: '/api/cart',
    ORDERS: '/api/orders',
    LOGIN: '/api/users/login',
    REGISTER: '/api/users/register',
    ADMIN_PRODUCTS: '/api/admin/products',
  };