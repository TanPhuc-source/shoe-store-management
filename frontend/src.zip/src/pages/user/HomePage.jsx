import React from 'react';
import ImageSlider from '../../components/ImageSlider';
import MainContent from '../../components/MainContent';  // Đảm bảo đường dẫn chính xác
import Sidebar from '../../components/Sidebar';

function HomePage() {
  return (
    <div className="container mx-auto p-4">
      <ImageSlider />
      <div className="flex flex-col md:flex-row gap-4">
        <Sidebar />
        <MainContent />
      </div>
    </div>
  );
}

export default HomePage;