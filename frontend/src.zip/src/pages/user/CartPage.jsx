import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { getCart } from '../../services/cartService';

function CartPage() {
  const [cartItems, setCartItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchCart = async () => {
      try {
        setLoading(true);
        setError(null);
        const response = await getCart();
        setCartItems(response.data || []);
      } catch (error) {
        console.error('Lỗi khi lấy giỏ hàng:', error);
        setError('Không thể tải giỏ hàng. Vui lòng thử lại sau.');
      } finally {
        setLoading(false);
      }
    };

    fetchCart();
  }, []);

  const handleQuantityChange = (itemId, newQuantity) => {
    // Logic cập nhật số lượng (giả lập)
    setCartItems(
      cartItems.map((item) =>
        item.id === itemId ? { ...item, quantity: Math.max(1, newQuantity) } : item
      )
    );
  };

  const handleRemoveItem = (itemId) => {
    // Logic xóa sản phẩm (giả lập)
    setCartItems(cartItems.filter((item) => item.id !== itemId));
  };

  const totalPrice = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);

  if (loading) return <p className="text-center">Đang tải giỏ hàng...</p>;
  if (error) return <p className="text-center text-red-500">{error}</p>;
  if (cartItems.length === 0) return <p className="text-center">Giỏ hàng trống.</p>;

  return (
    <main className="max-w-7xl mx-auto px-6 py-12 bg-gray-50 text-gray-900">
      <h1 className="text-4xl font-bold mb-8 text-gray-800 font-serif">Giỏ hàng của bạn</h1>

      {/* Cart Items */}
      <div className="space-y-6">
        {cartItems.map((item) => (
          <div
            key={item.id}
            className="flex flex-col md:flex-row items-center bg-white rounded-lg shadow-lg p-4 hover:shadow-xl transition-shadow duration-300"
          >
            {/* Product Image */}
            <img
              src={item.imageUrl || 'https://via.placeholder.com/300'}
              alt={item.productName}
              className="w-32 h-32 object-cover rounded-lg mr-4"
            />

            {/* Product Details */}
            <div className="flex-1">
              <h3 className="text-xl font-semibold text-gray-800">{item.productName}</h3>
              <p className="text-gray-600 mb-2">Kích cỡ: {item.size || 'N/A'}</p>
              <p className="text-gray-600 mb-2">Màu: {item.color || 'N/A'}</p>
              <span className="text-lg font-bold text-gray-900">
                {item.price.toLocaleString()} VND
              </span>
            </div>

            {/* Quantity and Remove */}
            <div className="flex items-center space-x-4 mt-4 md:mt-0">
              <input
                type="number"
                min="1"
                value={item.quantity}
                onChange={(e) => handleQuantityChange(item.id, parseInt(e.target.value) || 1)}
                className="w-20 px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-gray-900"
              />
              <button
                onClick={() => handleRemoveItem(item.id)}
                className="text-red-500 hover:text-red-700 transition"
              >
                <i className="fas fa-trash"></i>
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Total and Checkout */}
      <div className="mt-8 p-4 bg-white rounded-lg shadow-lg">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-2xl font-semibold text-gray-800">Tổng cộng</h2>
          <span className="text-2xl font-bold text-gray-900">
            {totalPrice.toLocaleString()} VND
          </span>
        </div>
        <Link
          to="/checkout"
          className="bg-gray-900 text-white font-semibold py-3 px-8 rounded shadow-lg hover:bg-gray-700 transition duration-300 flex items-center gap-2 w-full text-center"
        >
          <i className="fas fa-credit-card"></i> Thanh toán
        </Link>
      </div>
    </main>
  );
}

export default CartPage;