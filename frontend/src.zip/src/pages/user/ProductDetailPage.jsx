import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { getProductById, getProducts } from '../../services/productService';

function ProductDetailPage() {
  const { productId } = useParams();
  const [product, setProduct] = useState(null);
  const [relatedProducts, setRelatedProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedSize, setSelectedSize] = useState(null);
  const [selectedColor, setSelectedColor] = useState(null);
  const [quantity, setQuantity] = useState(1);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        setError(null);

        const productResponse = await getProductById(productId);
        console.log('Dữ liệu sản phẩm:', productResponse.data);
        setProduct(productResponse.data);

        const relatedResponse = await getProducts({ page: 0, size: 4 });
        setRelatedProducts(relatedResponse.data.content || []);
      } catch (error) {
        console.error('Lỗi khi lấy dữ liệu:', error);
        if (error.response?.status === 404) {
          setError('Sản phẩm không tồn tại.');
        } else {
          setError('Không thể tải dữ liệu. Vui lòng thử lại sau.');
        }
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [productId]);

  const handleAddToCart = () => {
    if (!selectedSize) {
      alert('Vui lòng chọn kích cỡ!');
      return;
    }
    if (!selectedColor) {
      alert('Vui lòng chọn màu sắc!');
      return;
    }
    alert(`Đã thêm ${product.productName} (kịch cỡ ${selectedSize.size}, màu ${selectedColor}, số lượng ${quantity}) vào giỏ hàng!`);
  };

  if (loading) return <p className="text-center">Đang tải...</p>;
  if (error) return <p className="text-center text-red-500">{error}</p>;
  if (!product) return <p className="text-center">Không có thông tin sản phẩm.</p>;

  const sizes = product.productSizes || [];

  return (
    <main className="max-w-7xl mx-auto px-6 py-12 bg-gray-50 text-gray-900">
      <div className="flex flex-col md:flex-row gap-12">
        <section className="md:w-1/2">
          {product.imageUrl ? (
            <img
              src={product.imageUrl}
              alt={product.productName}
              className="w-full rounded-lg shadow-lg object-cover transform hover:scale-105 transition-transform duration-300"
            />
          ) : (
            <div className="w-full h-96 bg-gray-200 flex items-center justify-center rounded-lg shadow-lg">
              <p className="text-gray-500">Không có hình ảnh</p>
            </div>
          )}
        </section>

        <section className="md:w-1/2 flex flex-col justify-between">
          <div>
            <h1 className="text-4xl font-bold mb-4 text-gray-800 font-serif">{product.productName}</h1>
            <p className="text-gray-600 mb-6 leading-relaxed">{product.description || 'Không có mô tả.'}</p>
            <span className="text-3xl font-bold text-gray-900 mb-6 block">{product.price.toLocaleString()} VND</span>

            <div className="mb-6">
              <h3 className="font-semibold mb-2 text-gray-800">Kích cỡ</h3>
              <div className="flex flex-wrap gap-3">
                {sizes.length > 0 ? (
                  sizes.map((size) => (
                    <label
                      key={size.sizeId}
                      className={`border border-gray-300 rounded px-4 py-2 cursor-pointer transition ${
                        selectedSize?.sizeId === size.sizeId ? 'bg-gray-200' : 'hover:bg-gray-200'
                      } ${size.quantity === 0 ? 'opacity-50 cursor-not-allowed' : ''}`}
                    >
                      <input
                        type="radio"
                        name="size"
                        className="hidden"
                        onChange={() => setSelectedSize(size)}
                        disabled={size.quantity === 0}
                      />
                      {size.size} {size.quantity > 0 ? `(${size.quantity})` : '(Hết)'}
                    </label>
                  ))
                ) : (
                  <p className="text-gray-600">Không có kích cỡ.</p>
                )}
              </div>
            </div>

            <div className="mb-6">
              <h3 className="font-semibold mb-2 text-gray-800">Màu sắc</h3>
              <div className="flex gap-4">
                {['#000000', '#a0522d', '#c0c0c0'].map((color, index) => (
                  <label
                    key={index}
                    className={`w-8 h-8 rounded-full border-2 border-gray-300 cursor-pointer hover:shadow-md transition ${
                      selectedColor === color ? 'ring-2 ring-gray-900' : ''
                    }`}
                    style={{ backgroundColor: color }}
                  >
                    <input
                      type="radio"
                      name="color"
                      className="hidden"
                      onChange={() => setSelectedColor(color)}
                    />
                  </label>
                ))}
              </div>
            </div>

            <div className="flex items-center gap-6">
              <input
                type="number"
                min="1"
                value={quantity}
                onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                className="w-20 px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-gray-900"
              />
              <button
                onClick={handleAddToCart}
                className="bg-gray-900 text-white font-semibold py-3 px-8 rounded shadow-lg hover:bg-gray-700 transition duration-300 flex items-center gap-2"
                disabled={product.status !== 'available'}
              >
                <i className="fas fa-shopping-cart"></i> Thêm vào giỏ hàng
              </button>
            </div>
          </div>
        </section>
      </div>

      <section className="mt-16">
        <h2 className="text-3xl font-bold mb-8 text-gray-800 text-center font-serif">Sản phẩm liên quan</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-8">
          {relatedProducts.length > 0 ? (
            relatedProducts.map((relatedProduct) => (
              <div
                key={relatedProduct.productId}
                className="border border-gray-200 rounded-lg overflow-hidden shadow-lg hover:shadow-2xl transition-shadow duration-300 transform hover:scale-105"
              >
                <img
                  src={relatedProduct.imageUrl || 'https://via.placeholder.com/300'}
                  alt={relatedProduct.productName}
                  className="w-full h-64 object-cover"
                />
                <div className="p-4 text-center">
                  <h3 className="text-lg font-semibold mb-1 text-gray-800">{relatedProduct.productName}</h3>
                  <span className="text-gray-900 font-bold">{relatedProduct.price.toLocaleString()} VND</span>
                </div>
              </div>
            ))
          ) : (
            <p className="text-center col-span-4">Không có sản phẩm liên quan.</p>
          )}
        </div>
      </section>
    </main>
  );
}

export default ProductDetailPage;