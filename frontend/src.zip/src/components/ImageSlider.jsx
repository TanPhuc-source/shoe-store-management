import React from 'react';

function ImageSlider() {
  return (
    <div className="w-full h-64 bg-gray-300 flex items-center justify-center mb-4">
      <p className="text-gray-600">Slider hình ảnh (chưa triển khai)</p>
    </div>
  );
}

export default ImageSlider;