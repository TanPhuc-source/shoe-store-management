import React from 'react';

function FilterSidebar({ filters, onFilterChange, onResetFilters }) {
  return (
    <div className="bg-gray-50 p-6 rounded-lg shadow-lg">
      <h2 className="text-2xl font-bold mb-6 font-playfair">Filter Products</h2>

      {/* Search Filter */}
      <div className="mb-6">
        <h3 className="font-semibold mb-3">Search</h3>
        <input
          type="text"
          name="name"
          placeholder="Search products..."
          value={filters.name}
          onChange={onFilterChange}
          className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-gray-900"
        />
      </div>

      {/* Category Filter */}
      <div className="mb-6">
        <h3 className="font-semibold mb-3">Category</h3>
        <ul className="space-y-2 text-gray-700">
          {filters.categories.map((cat) => (
            <li key={cat.categoryId}>
              <label className="inline-flex items-center">
                <input
                  type="checkbox"
                  name="categoryIds"
                  value={cat.categoryId}
                  checked={filters.categoryIds.includes(cat.categoryId.toString())}
                  onChange={onFilterChange}
                  className="form-checkbox"
                />
                {cat.categoryName}
              </label>
            </li>
          ))}
        </ul>
      </div>

      {/* Price Filter */}
      <div className="mb-6">
        <h3 className="font-semibold mb-3">Price Range</h3>
        <div className="flex items-center gap-4">
          <input
            type="number"
            name="minPrice"
            placeholder="Min"
            value={filters.minPrice}
            onChange={onFilterChange}
            className="w-1/2 px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-gray-900"
          />
          <input
            type="number"
            name="maxPrice"
            placeholder="Max"
            value={filters.maxPrice}
            onChange={onFilterChange}
            className="w-1/2 px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-gray-900"
          />
        </div>
      </div>

      {/* Brand Filter */}
      <div className="mb-6">
        <h3 className="font-semibold mb-3">Brand</h3>
        <ul className="space-y-2 text-gray-700">
          {filters.brands.map((brand) => (
            <li key={brand.brandId}>
              <label className="inline-flex items-center">
                <input
                  type="checkbox"
                  name="brandIds"
                  value={brand.brandId}
                  checked={filters.brandIds.includes(brand.brandId.toString())}
                  onChange={onFilterChange}
                  className="form-checkbox"
                />
                {brand.brandName}
              </label>
            </li>
          ))}
        </ul>
      </div>

      {/* Size Filter */}
      <div className="mb-6">
        <h3 className="font-semibold mb-3">Size</h3>
        <ul className="flex flex-wrap gap-2 text-gray-700">
          {[6, 7, 8, 9, 10, 11].map((size) => (
            <li key={size}>
              <label className="inline-flex items-center border border-gray-300 rounded px-3 py-1 cursor-pointer hover:bg-gray-200">
                <input
                  type="checkbox"
                  name="sizeIds"
                  value={size}
                  checked={filters.sizeIds?.includes(size.toString()) || false}
                  onChange={onFilterChange}
                  className="form-checkbox hidden"
                />
                {size}
              </label>
            </li>
          ))}
        </ul>
      </div>

      {/* Color Filter */}
      <div>
        <h3 className="font-semibold mb-3">Color</h3>
        <div className="flex gap-3">
          {['#000000', '#ffffff', '#a0522d', '#c0c0c0', '#ff0000'].map((color) => (
            <label
              key={color}
              className="w-6 h-6 rounded-full border-2 border-gray-300 cursor-pointer hover:shadow-md"
              style={{ backgroundColor: color }}
            >
              <input
                type="radio"
                name="color"
                value={color}
                checked={filters.color === color}
                onChange={onFilterChange}
                className="hidden"
              />
            </label>
          ))}
        </div>
      </div>

      {/* Reset Button */}
      <button
        onClick={onResetFilters}
        className="w-full mt-6 px-4 py-2 bg-gray-900 text-white rounded hover:bg-gray-800 transition"
      >
        Clear Filters
      </button>
    </div>
  );
}

export default FilterSidebar;