import React, { useContext } from 'react';
import FilterSidebar from './FilterSidebar';
import { FilterContext } from '../context/FilterContext'; // Đường dẫn vẫn đúng sau khi đổi tên

function Sidebar() {
  const { filters, handleFilterChange, handleResetFilters } = useContext(FilterContext);

  return (
    <div className="w-full md:w-1/4 p-4 bg-gray-200">
      <h3 className="text-xl font-bold mb-4">Bộ lọc</h3>
      <FilterSidebar
        filters={filters}
        onFilterChange={handleFilterChange}
        onResetFilters={handleResetFilters}
      />
    </div>
  );
}

export default Sidebar;