import React from 'react';
import { FaFacebookF, FaPinterestP, FaYoutube, FaInstagram, FaTiktok } from 'react-icons/fa';
import { SiVisa, SiMastercard, SiJcb } from 'react-icons/si';

function Footer() {
  return (
    <footer className="bg-gray-100 py-12">
      <div className="container mx-auto grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-8 px-4">
        {/* Cột 1: Thông tin cửa hàng */}
        <div>
          <div className="flex items-center mb-4">
            <span className="text-2xl font-bold text-black">SHO</span>
            <span className="text-2xl font-bold text-orange-500">ES</span>
          </div>
          <p className="text-gray-600 text-sm">
            SHOES luôn cam kết đảm bảo đưa sản phẩm trực tiếp từ nhà sản xuất đến tay người dùng
            và kiểm soát được chất lượng tốt đáp ứng được nhu cầu ngày càng cao của khách hàng. Tất cả các
            sản phẩm tại SHOES đều có nguồn gốc xuất xứ rõ ràng, chất lượng.
          </p>
        </div>

        {/* Cột 2: Liên hệ */}
        <div>
          <h6 className="font-semibold text-gray-700 mb-2 uppercase">Liên hệ</h6>
          <ul className="text-gray-600 text-sm space-y-2">
            <li>Tư vấn dịch vụ: 1800 6750</li>
            <li>Hỗ trợ sử dụng: 1900 6750</li>
            <li>Hỗ trợ vận chuyển: 1900 6779</li>
            <li>Email: support@shoes.vn</li>
            <li>Giờ: 7h00 - 22h00 các ngày từ thứ 2 đến Chủ nhật</li>
          </ul>
        </div>

        {/* Cột 3: Về chúng tôi */}
        <div>
          <h6 className="font-semibold text-gray-700 mb-2 uppercase">Về chúng tôi</h6>
          <ul className="text-gray-600 text-sm space-y-2">
            <li>Giới thiệu</li>
            <li>Chính sách đổi trả</li>
            <li>Chính sách bảo mật</li>
            <li>Điều khoản dịch vụ</li>
          </ul>
        </div>

        {/* Cột 4: Danh mục nổi bật */}
        <div>
          <h6 className="font-semibold text-gray-700 mb-2 uppercase">Danh mục nổi bật</h6>
          <ul className="text-gray-600 text-sm space-y-2">
            <li>Chuck 2</li>
            <li>Converse All Star</li>
            <li>Socks</li>
            <li>Jack Purcell</li>
            <li>Converse Seasonal</li>
          </ul>
        </div>

        {/* Cột 5: Liên hệ với chúng tôi */}
        <div>
          <h6 className="font-semibold text-gray-700 mb-2 uppercase">Liên hệ với chúng tôi</h6>
          <p className="text-gray-600 text-sm mb-2">
            Luôn cập nhật tất cả các hành động mới nhất của chúng tôi để
            làm cho tất cả khách hàng của mình.
          </p>
          <div className="flex space-x-4">
            <a href="#" className="text-blue-500 hover:opacity-80">
              <FaFacebookF size={20} />
            </a>
            <a href="#" className="text-red-500 hover:opacity-80">
              <FaPinterestP size={20} />
            </a>
            <a href="#" className="text-red-600 hover:opacity-80">
              <FaYoutube size={20} />
            </a>
            <a href="#" className="text-pink-500 hover:opacity-80">
              <FaInstagram size={20} />
            </a>
            <a href="#" className="text-black hover:opacity-80">
              <FaTiktok size={20} />
            </a>
          </div>
        </div>
      </div>

      {/* Phần bản quyền và thanh toán */}
      <div className="bg-gray-200 py-4 mt-8">
        <div className="container mx-auto flex items-center justify-between px-4 text-gray-600 text-xs">
          <p>© 2025 - Bản quyền thuộc về <span className="text-orange-500">NGÔ TẤN PHÚC</span></p>
          <div className="flex space-x-4">
            <SiVisa size={30} />
            <SiMastercard size={30} />
            <SiJcb size={30} />
          </div>
        </div>
      </div>
    </footer>
  );
}

export default Footer;