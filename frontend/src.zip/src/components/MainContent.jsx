import React, { useEffect, useState, useContext } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { FilterContext } from '../context/FilterContext'; // Đường dẫn vẫn đúng
import { getProducts } from '../services/productService';

function MainContent() {
  const { filters } = useContext(FilterContext);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [currentPage, setCurrentPage] = useState(0);
  const [totalPages, setTotalPages] = useState(1);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        setLoading(true);
        setError(null);
        const params = {
          page: currentPage,
          size: 10,
          name: filters.name,
          minPrice: filters.minPrice,
          maxPrice: filters.maxPrice,
          status: filters.status,
          color: filters.color,
        };
        if (filters.categoryIds.length > 0) {
          params.categoryId = filters.categoryIds.join(',');
        }
        if (filters.brandIds.length > 0) {
          params.brandId = filters.brandIds.join(',');
        }
        if (filters.sizeIds?.length > 0) {
          params.size = filters.sizeIds.join(',');
        }
        const response = await getProducts(params);
        setProducts(response.data.content || []);
        setTotalPages(response.data.totalPages || 1);
      } catch (error) {
        console.error('Lỗi khi lấy sản phẩm:', error);
        if (error.response?.status === 403) {
          setError('Truy cập bị từ chối. Vui lòng kiểm tra quyền truy cập.');
        } else if (error.response?.status === 500) {
          setError('Lỗi server. Vui lòng thử lại sau.');
        } else {
          setError('Không thể tải sản phẩm. Vui lòng thử lại sau.');
        }
      } finally {
        setLoading(false);
      }
    };

    fetchProducts();
  }, [currentPage, filters]);

  const handlePageChange = (page) => {
    if (page >= 0 && page < totalPages) {
      setCurrentPage(page);
    }
  };

  if (loading) return <p className="text-center">Đang tải sản phẩm...</p>;
  if (error) return <p className="text-center text-red-500">{error}</p>;

  return (
    <div className="flex-1 p-4 bg-gray-100 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <h2 className="text-2xl font-bold mb-4 font-playfair">Danh sách sản phẩm</h2>
        <div className="w-full">
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {products.length > 0 ? (
              products.map((product) => (
                <Link
                  to={`/products/${product.productId}`}
                  key={product.productId}
                  className="border border-gray-200 rounded-lg overflow-hidden shadow-lg hover:shadow-2xl transition-shadow duration-300"
                >
                  {product.imageUrl ? (
                    <img
                      src={product.imageUrl}
                      alt={product.productName}
                      className="w-full h-48 object-cover rounded-t-lg"
                    />
                  ) : (
                    <div className="w-full h-48 bg-gray-200 flex items-center justify-center rounded-t-lg">
                      <p className="text-gray-500">No image</p>
                    </div>
                  )}
                  <div className="p-4 text-center">
                    <h3 className="text-lg font-semibold mb-1">{product.productName}</h3>
                    <p className="text-gray-600 mb-2">Price: {product.price.toLocaleString()} VND</p>
                    <p className="text-gray-600">
                      Status: {product.status === 'available' ? 'In Stock' : 'Out of Stock'}
                    </p>
                  </div>
                </Link>
              ))
            ) : (
              <p className="text-center col-span-4">No products to display.</p>
            )}
          </div>

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex justify-center mt-4">
              <button
                onClick={() => handlePageChange(currentPage - 1)}
                disabled={currentPage === 0}
                className="px-4 py-2 mx-1 bg-gray-200 rounded disabled:opacity-50"
              >
                Previous
              </button>
              {Array.from({ length: totalPages }, (_, i) => (
                <button
                  key={i}
                  onClick={() => handlePageChange(i)}
                  className={`px-4 py-2 mx-1 ${
                    currentPage === i ? 'bg-blue-500 text-white' : 'bg-gray-200'
                  } rounded`}
                >
                  {i + 1}
                </button>
              ))}
              <button
                onClick={() => handlePageChange(currentPage + 1)}
                disabled={currentPage === totalPages - 1}
                className="px-4 py-2 mx-1 bg-gray-200 rounded disabled:opacity-50"
              >
                Next
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default MainContent;