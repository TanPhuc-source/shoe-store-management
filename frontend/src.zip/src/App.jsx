import { RouterProvider } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import router from './routes';
import { FilterProvider } from './context/FilterContext'; // Đường dẫn vẫn đúng

function App() {
  return (
    <AuthProvider>
      <FilterProvider>
      <RouterProvider router={router} />
      </FilterProvider>
    </AuthProvider>
  );
}

export default App;