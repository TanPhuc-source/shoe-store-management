const products = [
    { id: 1, name: 'Giày Nike Air Max', price: 2500000, image: 'https://via.placeholder.com/150' },
    { id: 2, name: 'Giày Adidas Ultraboost', price: 3200000, image: 'https://via.placeholder.com/150' },
    { id: 3, name: 'Giày Puma RS-X', price: 1800000, image: 'https://via.placeholder.com/150' },
  ];
  
  export default products;