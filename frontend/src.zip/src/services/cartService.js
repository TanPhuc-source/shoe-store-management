import axios from 'axios';

const API_URL = 'http://localhost:8080/api';

export const getCart = async () => {
  try {
    const response = await axios.get(`${API_URL}/cart`, {
      headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }, // Giả định cần token
    });
    return response.data;
  } catch (error) {
    throw error;
  }
};

// Thêm các phương thức khác (update, remove) khi cần