package com.shoes.bangiay.service.impl;

import com.shoes.bangiay.DTO.response.ProductSizeDTO;
import com.shoes.bangiay.entity.ProductSize;
import com.shoes.bangiay.repository.ProductSizeRepository;
import com.shoes.bangiay.service.ProductSizeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ProductSizeServiceImpl implements ProductSizeService {
    @Autowired
    private ProductSizeRepository productSizeRepository;

    @Override
    public List<ProductSizeDTO> getProductSizesByProductId(Integer productId) {
        return productSizeRepository.findAll().stream()
                .filter(ps -> ps.getProduct().getProductId().equals(productId))
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    private ProductSizeDTO mapToDTO(ProductSize productSize) {
        ProductSizeDTO dto = new ProductSizeDTO();
        dto.setSizeId(productSize.getSizeId());
        dto.setSize(productSize.getSize());
        dto.setQuantity(productSize.getQuantity());
        return dto;
    }
}