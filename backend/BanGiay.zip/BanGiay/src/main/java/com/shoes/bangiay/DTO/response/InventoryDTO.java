package com.shoes.bangiay.DTO.response;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class InventoryDTO {
    private Integer inventoryId;
    private Integer productId;
    private String productName;
    private Integer sizeId;
    private String size;
    private Integer quantity;
    private LocalDateTime lastUpdated;
}