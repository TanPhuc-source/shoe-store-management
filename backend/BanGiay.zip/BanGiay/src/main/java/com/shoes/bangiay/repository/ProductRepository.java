package com.shoes.bangiay.repository;

import com.shoes.bangiay.entity.Product;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

public interface ProductRepository extends JpaRepository<Product, Integer> {
    // Truy vấn để lấy chi tiết một sản phẩm với Category, Brand và ProductSizes
    @Query("SELECT p FROM Product p " +
            "JOIN FETCH p.category " +
            "JOIN FETCH p.brand " +
            "LEFT JOIN FETCH p.productSizes " +
            "WHERE p.productId = :productId")
    Optional<Product> findByIdWithCategoryAndBrand(Integer productId);

    // Truy vấn để lấy danh sách sản phẩm với Category, Brand và ProductSizes (phân trang)
    @Query("SELECT p FROM Product p JOIN FETCH p.category JOIN FETCH p.brand")
    Page<Product> findAllWithCategoryAndBrand(Pageable pageable);
}
