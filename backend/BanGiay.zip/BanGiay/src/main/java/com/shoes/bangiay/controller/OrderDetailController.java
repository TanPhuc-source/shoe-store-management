package com.shoes.bangiay.controller;

import com.shoes.bangiay.DTO.response.OrderDetailDTO;
import com.shoes.bangiay.service.OrderDetailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/admin/order-details")
public class OrderDetailController {
    @Autowired
    private OrderDetailService orderDetailService;

    // API 1: Lấy danh sách tất cả chi tiết đơn hàng
    @GetMapping("/all")
    public ResponseEntity<List<OrderDetailDTO>> getAllOrderDetails() {
        List<OrderDetailDTO> orderDetails = orderDetailService.getAllOrderDetails();
        return new ResponseEntity<>(orderDetails, HttpStatus.OK);
    }

    // API 2: Lấy thông tin chi tiết đơn hàng theo ID
    @GetMapping("/{order_detail_id}")
    public ResponseEntity<OrderDetailDTO> getOrderDetailById(@PathVariable("order_detail_id") Integer id) {
        OrderDetailDTO orderDetail = orderDetailService.getOrderDetailById(id);
        return new ResponseEntity<>(orderDetail, HttpStatus.OK);
    }

    // API 3: Cập nhật chi tiết đơn hàng
    @PutMapping("/{order_detail_id}")
    public ResponseEntity<OrderDetailDTO> updateOrderDetail(
            @PathVariable("order_detail_id") Integer id,
            @RequestBody OrderDetailDTO request) {
        OrderDetailDTO updatedOrderDetail = orderDetailService.updateOrderDetail(id, request);
        return new ResponseEntity<>(updatedOrderDetail, HttpStatus.OK);
    }

    // API 4: Xóa chi tiết đơn hàng
    @DeleteMapping("/{order_detail_id}")
    public ResponseEntity<Void> deleteOrderDetail(@PathVariable("order_detail_id") Integer id) {
        orderDetailService.deleteOrderDetail(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
