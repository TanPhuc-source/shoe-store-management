package com.shoes.bangiay.controller;

import com.shoes.bangiay.DTO.request.AddToCartRequest;
import com.shoes.bangiay.DTO.request.UpdateCartRequest;
import com.shoes.bangiay.DTO.response.CartDTO;
import com.shoes.bangiay.service.CartService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class CartController {
    @Autowired
    private CartService cartService;

    // GET /api/cart
    @GetMapping("/cart")
    public ResponseEntity<List<CartDTO>> getCartByUserId() {
        List<CartDTO> cartItems = cartService.getCartByUserId();
        return new ResponseEntity<>(cartItems, HttpStatus.OK);
    }

    // POST /api/cart
    @PostMapping("/cart")
    public ResponseEntity<CartDTO> addToCart(@Valid @RequestBody AddToCartRequest request) {
        CartDTO cartDTO = cartService.addToCart(request);
        return ResponseEntity.status(201).body(cartDTO);
    }

    // PUT /api/cart/:cart_id
    @PutMapping("/cart/{cartId}")
    public ResponseEntity<CartDTO> updateCartItem(
            @PathVariable Integer cartId,
            @Valid @RequestBody UpdateCartRequest request) {
        CartDTO updatedCart = cartService.updateCartItem(cartId, request);
        return ResponseEntity.ok(updatedCart);
    }

    // DELETE /api/cart/:cart_id
    @DeleteMapping("/cart/{cartId}")
    public ResponseEntity<Void> deleteCartItem(@PathVariable Integer cartId) {
        cartService.deleteCartItem(cartId);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    // DELETE /api/cart/clear
    @DeleteMapping("/cart/clear")
    public ResponseEntity<Void> clearCart() {
        cartService.clearCart();
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}