package com.shoes.bangiay.controller;

import com.shoes.bangiay.DTO.request.CreateInventoryRequest;
import com.shoes.bangiay.DTO.request.UpdateInventoryRequest;
import com.shoes.bangiay.DTO.response.InventoryDTO;
import com.shoes.bangiay.service.InventoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/admin")
public class InventoryController {
    @Autowired
    private InventoryService inventoryService;

    // POST /api/admin/inventory
    @PostMapping("/inventory")
    public ResponseEntity<InventoryDTO> createInventory(@RequestBody CreateInventoryRequest request) {
        InventoryDTO createdInventory = inventoryService.createInventory(request);
        return new ResponseEntity<>(createdInventory, HttpStatus.CREATED);
    }

    // GET /api/admin/inventory
    @GetMapping("/inventory")
    public ResponseEntity<Page<InventoryDTO>> getAllInventory(Pageable pageable) {
        Page<InventoryDTO> inventory = inventoryService.getAllInventory(pageable);
        return new ResponseEntity<>(inventory, HttpStatus.OK);
    }

    // PUT /api/admin/inventory/:inventory_id
    @PutMapping("/inventory/{inventoryId}")
    public ResponseEntity<InventoryDTO> updateInventory(@PathVariable Integer inventoryId, @RequestBody UpdateInventoryRequest request) {
        InventoryDTO updatedInventory = inventoryService.updateInventory(inventoryId, request);
        return new ResponseEntity<>(updatedInventory, HttpStatus.OK);
    }

    // DELETE /api/admin/inventory/:inventory_id
    @DeleteMapping("/inventory/{inventoryId}")
    public ResponseEntity<Void> deleteInventory(@PathVariable Integer inventoryId) {
        inventoryService.deleteInventory(inventoryId);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}