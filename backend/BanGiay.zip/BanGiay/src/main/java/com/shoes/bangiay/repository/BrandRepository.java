package com.shoes.bangiay.repository;

import com.shoes.bangiay.entity.Brand;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BrandRepository extends JpaRepository<Brand, Integer> {
}
