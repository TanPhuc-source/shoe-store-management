package com.shoes.bangiay.enums;

import com.fasterxml.jackson.annotation.JsonProperty;

public enum OrderStatus {
    @JsonProperty("pending")
    PENDING,
    @JsonProperty("shipped")
    SHIPPED,
    @JsonProperty("delivered")
    DELIVERED,
    @JsonProperty("cancelled")
    CANCELLED
}
