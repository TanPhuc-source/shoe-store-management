package com.shoes.bangiay.service;

import com.shoes.bangiay.DTO.request.CreateStaffRequest;
import com.shoes.bangiay.DTO.request.UpdateStaffRequest;
import com.shoes.bangiay.DTO.response.StaffDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface StaffService {
    StaffDTO createStaff(CreateStaffRequest request);
    Page<StaffDTO> getAllStaff(Pageable pageable);
    StaffDTO updateStaff(Integer staffId, UpdateStaffRequest request);
    void deleteStaff(Integer staffId);
}