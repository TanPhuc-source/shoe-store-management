package com.shoes.bangiay.DTO.response;

import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
public class StaffDTO {
    private Integer staffId;
    private Integer userId;
    private String username;
    private String position;
    private LocalDate hireDate;
    private BigDecimal salary;
}