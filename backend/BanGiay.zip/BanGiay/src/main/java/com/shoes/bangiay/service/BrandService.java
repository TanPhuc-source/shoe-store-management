package com.shoes.bangiay.service;

import com.shoes.bangiay.DTO.response.BrandDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface BrandService {
    List<BrandDTO> getAllBrands();
    BrandDTO getBrandById(Integer brandId);
    Page<BrandDTO> getAllBrandsForAdmin(Pageable pageable);
    BrandDTO createBrand(BrandDTO request);
    BrandDTO updateBrand(Integer brandId, BrandDTO request);
    void deleteBrand(Integer brandId);
}