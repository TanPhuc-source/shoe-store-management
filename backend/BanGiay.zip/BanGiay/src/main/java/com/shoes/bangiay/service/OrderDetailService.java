package com.shoes.bangiay.service;

import com.shoes.bangiay.DTO.response.OrderDetailDTO;

import java.util.List;
public interface OrderDetailService {
    List<OrderDetailDTO> getAllOrderDetails();
    OrderDetailDTO getOrderDetailById(Integer id);
    OrderDetailDTO updateOrderDetail(Integer id, OrderDetailDTO request);
    void deleteOrderDetail(Integer id);
}
