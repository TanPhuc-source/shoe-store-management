package com.shoes.bangiay.service.impl;

import com.shoes.bangiay.DTO.response.BrandDTO;
import com.shoes.bangiay.entity.Brand;
import com.shoes.bangiay.repository.BrandRepository;
import com.shoes.bangiay.service.BrandService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class BrandServiceImpl implements BrandService {
    @Autowired
    private BrandRepository brandRepository;

    @Override
    public List<BrandDTO> getAllBrands() {
        return brandRepository.findAll().stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public BrandDTO getBrandById(Integer brandId) {
        Brand brand = brandRepository.findById(brandId)
                .orElseThrow(() -> new RuntimeException("Brand not found"));
        return mapToDTO(brand);
    }

    @Override
    public Page<BrandDTO> getAllBrandsForAdmin(Pageable pageable) {
        return brandRepository.findAll(pageable)
                .map(this::mapToDTO);
    }

    @Override
    public BrandDTO createBrand(BrandDTO request) {
        Brand brand = new Brand();
        brand.setBrandName(request.getBrandName());
        brand.setDescription(request.getDescription());

        Brand savedBrand = brandRepository.save(brand);
        return mapToDTO(savedBrand);
    }

    @Override
    public BrandDTO updateBrand(Integer brandId, BrandDTO request) {
        Brand brand = brandRepository.findById(brandId)
                .orElseThrow(() -> new RuntimeException("Brand not found"));

        brand.setBrandName(request.getBrandName());
        brand.setDescription(request.getDescription());

        Brand updatedBrand = brandRepository.save(brand);
        return mapToDTO(updatedBrand);
    }

    @Override
    public void deleteBrand(Integer brandId) {
        Brand brand = brandRepository.findById(brandId)
                .orElseThrow(() -> new RuntimeException("Brand not found"));
        if (!brand.getProducts().isEmpty()) {
            throw new RuntimeException("Cannot delete brand with associated products");
        }
        brandRepository.delete(brand);
    }

    private BrandDTO mapToDTO(Brand brand) {
        BrandDTO dto = new BrandDTO();
        dto.setBrandId(brand.getBrandId());
        dto.setBrandName(brand.getBrandName());
        dto.setDescription(brand.getDescription());
        return dto;
    }
}