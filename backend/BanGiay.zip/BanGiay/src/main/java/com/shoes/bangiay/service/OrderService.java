package com.shoes.bangiay.service;

import com.shoes.bangiay.DTO.request.CreateOrderRequest;
import com.shoes.bangiay.DTO.request.UpdateOrderRequest;
import com.shoes.bangiay.DTO.response.OrderDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
public interface OrderService {
    OrderDTO createOrder(CreateOrderRequest request);
    List<OrderDTO> getOrdersByUserId();
    OrderDTO getOrderById(Integer orderId);
    OrderDTO updateOrder(Integer orderId, UpdateOrderRequest request); // Thay updateOrderStatus
    Page<OrderDTO> getAllOrdersForAdmin(Pageable pageable);
    void deleteOrder(Integer orderId);
}
