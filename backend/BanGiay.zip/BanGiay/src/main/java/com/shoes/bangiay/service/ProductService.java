package com.shoes.bangiay.service;

import com.shoes.bangiay.DTO.request.CreateProductRequest;
import com.shoes.bangiay.DTO.response.ProductDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface ProductService {
    ProductDTO getProductById(Integer productId);
    Page<ProductDTO> getAllProducts(String search, Integer categoryId, Integer brandId, Pageable pageable);
    ProductDTO createProduct(CreateProductRequest request);
    ProductDTO updateProduct(Integer productId, CreateProductRequest request);
    void deleteProduct(Integer productId);
}
