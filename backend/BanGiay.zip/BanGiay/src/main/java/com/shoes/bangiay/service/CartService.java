package com.shoes.bangiay.service;

import com.shoes.bangiay.DTO.request.AddToCartRequest;
import com.shoes.bangiay.DTO.request.UpdateCartRequest;
import com.shoes.bangiay.DTO.response.CartDTO;

import java.util.List;

public interface CartService {
    List<CartDTO> getCartByUserId();
    CartDTO addToCart(AddToCartRequest request);
    CartDTO updateCartItem(Integer cartId, UpdateCartRequest request);
    void deleteCartItem(Integer cartId);
    void clearCart();
}