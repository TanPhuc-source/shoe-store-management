package com.shoes.bangiay.service.impl;

import com.shoes.bangiay.DTO.request.CreateStaffRequest;
import com.shoes.bangiay.DTO.request.UpdateStaffRequest;
import com.shoes.bangiay.DTO.response.StaffDTO;
import com.shoes.bangiay.entity.Staff;
import com.shoes.bangiay.entity.User;
import com.shoes.bangiay.repository.StaffRepository;
import com.shoes.bangiay.repository.UserRepository;
import com.shoes.bangiay.service.StaffService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.stream.Collectors;

@Service
public class StaffServiceImpl implements StaffService {
    @Autowired
    private StaffRepository staffRepository;

    @Autowired
    private UserRepository userRepository;

    @Override
    public StaffDTO createStaff(CreateStaffRequest request) {
        User user = userRepository.findById(request.getUserId())
                .orElseThrow(() -> new RuntimeException("User not found"));

        Staff staff = new Staff();
        staff.setUser(user);
        staff.setPosition(request.getPosition());
        staff.setHireDate(request.getHireDate());
        staff.setSalary(request.getSalary());

        Staff savedStaff = staffRepository.save(staff);
        return mapToDTO(savedStaff);
    }

    @Override
    public Page<StaffDTO> getAllStaff(Pageable pageable) {
        return staffRepository.findAll(pageable)
                .map(this::mapToDTO);
    }

    @Override
    public StaffDTO updateStaff(Integer staffId, UpdateStaffRequest request) {
        Staff staff = staffRepository.findById(staffId)
                .orElseThrow(() -> new RuntimeException("Staff not found"));

        staff.setPosition(request.getPosition());
        staff.setHireDate(request.getHireDate());
        staff.setSalary(request.getSalary());

        Staff updatedStaff = staffRepository.save(staff);
        return mapToDTO(updatedStaff);
    }

    @Override
    public void deleteStaff(Integer staffId) {
        Staff staff = staffRepository.findById(staffId)
                .orElseThrow(() -> new RuntimeException("Staff not found"));
        staffRepository.delete(staff);
    }

    private StaffDTO mapToDTO(Staff staff) {
        StaffDTO dto = new StaffDTO();
        dto.setStaffId(staff.getStaffId());
        dto.setUserId(staff.getUser().getUserId());
        dto.setUsername(staff.getUser().getUsername());
        dto.setPosition(staff.getPosition());
        dto.setHireDate(staff.getHireDate());
        dto.setSalary(staff.getSalary());
        return dto;
    }
}