package com.shoes.bangiay.DTO.response;

import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

@Data
public class ProductDTO {
    private Integer productId;
    private String productName;
    private String description;
    private BigDecimal price;
    private String imageUrl;
    private String status;
    private Integer categoryId;
    private String categoryName;
    private Integer brandId;
    private String brandName;
    private List<ProductSizeDTO> sizes;

    @Data
    public static class ProductSizeDTO {
        private Integer sizeId;
        private String size;
        private Integer quantity;
    }
}
