package com.shoes.bangiay.DTO.response;


import lombok.Data;

@Data
public class ProductSizeDTO {
    private Integer sizeId;
    private String size;
    private Integer quantity;
}
