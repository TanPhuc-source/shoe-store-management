package com.shoes.bangiay.DTO.request;

public class CreateCategoryRequest {
    private Integer categoryId;
    private String categoryName;
    private String description;
}
