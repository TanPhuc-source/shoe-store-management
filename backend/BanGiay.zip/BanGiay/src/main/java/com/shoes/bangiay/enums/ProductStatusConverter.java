package com.shoes.bangiay.enums;

import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;

@Converter(autoApply = true)
public class ProductStatusConverter implements AttributeConverter<ProductStatus, String> {

    @Override
    public String convertToDatabaseColumn(ProductStatus attribute) {
        if (attribute == null) {
            return null;
        }
        return attribute.toString(); // Sử dụng toString() để lưu giá trị chữ thường ("available", "unavailable")
    }

    @Override
    public ProductStatus convertToEntityAttribute(String dbData) {
        if (dbData == null) {
            return null;
        }
        return ProductStatus.fromValue(dbData); // Sử dụng fromValue để ánh xạ từ String về Enum
    }
}