package com.shoes.bangiay.service.impl;

import com.shoes.bangiay.DTO.request.AddToCartRequest;
import com.shoes.bangiay.DTO.request.UpdateCartRequest;
import com.shoes.bangiay.DTO.response.CartDTO;
import com.shoes.bangiay.entity.Cart;
import com.shoes.bangiay.entity.ProductSize;
import com.shoes.bangiay.entity.User;
import com.shoes.bangiay.repository.CartRepository;
import com.shoes.bangiay.repository.InventoryRepository;
import com.shoes.bangiay.repository.ProductSizeRepository;
import com.shoes.bangiay.repository.UserRepository;
import com.shoes.bangiay.service.CartService;
import jakarta.transaction.Transactional;
import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import com.shoes.bangiay.entity.Inventory;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class CartServiceImpl implements CartService {
    @Autowired
    private CartRepository cartRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private InventoryRepository inventoryRepository;

    @Autowired
    private ProductSizeRepository productSizeRepository;

    @Override
    public List<CartDTO> getCartByUserId() {
        // Lấy thông tin người dùng từ SecurityContext
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("User not found"));

        // Lấy carts dựa trên userId
        List<Cart> carts = cartRepository.findByUserId(user.getUserId()); // Truyền userId thay vì User
        return carts.stream().map(this::mapToDTO).collect(Collectors.toList());
    }

    @Override
    @Transactional
    public CartDTO addToCart(AddToCartRequest request) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("User not found"));

        ProductSize productSize = productSizeRepository.findById(request.getProductSizeId())
                .orElseThrow(() -> new RuntimeException("Product size not found"));

        Inventory inventory = inventoryRepository.findById(productSize.getSizeId())
                .orElseThrow(() -> new RuntimeException("Inventory not found"));

        if (inventory.getQuantity() < request.getQuantity()) {
            throw new RuntimeException("Insufficient stock for product size ID: " + productSize.getSizeId());
        }

        Cart cart = new Cart();
        cart.setUser(user);
        cart.setProductSize(productSize);
        cart.setQuantity(request.getQuantity());
        cart.setAddedAt(LocalDateTime.now());

        Cart savedCart = cartRepository.save(cart);

        inventory.setQuantity(inventory.getQuantity() - request.getQuantity());
        inventory.setLastUpdated(LocalDateTime.now());
        inventoryRepository.save(inventory);

        return mapToDTO(savedCart);
    }

    @Override
    @Transactional
    public CartDTO updateCartItem(Integer cartId, UpdateCartRequest request) {
        // Kiểm tra cartId
        if (cartId == null) {
            throw new IllegalArgumentException("Cart ID must not be null");
        }

        // Kiểm tra request
        if (request == null || request.getQuantity() == null) {
            throw new IllegalArgumentException("Request parameters must not be null");
        }

        // Kiểm tra quantity hợp lệ
        if (request.getQuantity() <= 0) {
            throw new IllegalArgumentException("Quantity must be greater than 0");
        }

        // Tìm cart theo ID
        Cart cart = cartRepository.findById(cartId)
                .orElseThrow(() -> new RuntimeException("Cart item not found with ID: " + cartId));

        // Kiểm tra quyền truy cập
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("User not found"));
        if (!cart.getUser().getUserId().equals(user.getUserId())) {
            throw new RuntimeException("You do not have permission to update this cart");
        }

        // Tải ProductSize và Product trước
        Hibernate.initialize(cart.getProductSize());
        ProductSize productSize = cart.getProductSize();
        Hibernate.initialize(productSize.getProduct());

        // Lấy thông tin hiện tại
        int currentQuantity = cart.getQuantity();
        int newQuantity = request.getQuantity();
        int quantityDifference = newQuantity - currentQuantity;

        // Kiểm tra và cập nhật tồn kho
        Inventory inventory = inventoryRepository.findById(productSize.getSizeId())
                .orElseThrow(() -> new RuntimeException("Inventory not found"));

        if (quantityDifference > 0 && inventory.getQuantity() < quantityDifference) {
            throw new RuntimeException("Insufficient stock for product size ID: " + productSize.getSizeId());
        }

        // Cập nhật số lượng trong cart
        cart.setQuantity(newQuantity);
        Cart updatedCart = cartRepository.save(cart);

        // Cập nhật tồn kho
        inventory.setQuantity(inventory.getQuantity() - quantityDifference);
        inventory.setLastUpdated(LocalDateTime.now());
        inventoryRepository.save(inventory);

        return mapToDTO(updatedCart);
    }

    @Override
    public void deleteCartItem(Integer cartId) {
        Cart cart = cartRepository.findById(cartId)
                .orElseThrow(() -> new RuntimeException("Cart item not found"));
        cartRepository.delete(cart);
    }

    @Override
    @Transactional
    public void clearCart() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !authentication.isAuthenticated()) {
            throw new RuntimeException("User not authenticated");
        }

        String username = authentication.getName();
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("User not found"));

        // Lấy danh sách giỏ hàng của người dùng
        List<Cart> carts = cartRepository.findByUserId(user.getUserId());

        // Hoàn trả tồn kho
        for (Cart cart : carts) {
            ProductSize productSize = cart.getProductSize();
            Hibernate.initialize(productSize); // Đảm bảo tải ProductSize
            Inventory inventory = inventoryRepository.findById(productSize.getSizeId())
                    .orElseThrow(() -> new RuntimeException("Inventory not found"));
            inventory.setQuantity(inventory.getQuantity() + cart.getQuantity());
            inventory.setLastUpdated(LocalDateTime.now());
            inventoryRepository.save(inventory);
        }

        // Xóa toàn bộ giỏ hàng
        cartRepository.deleteByUser(user);
    }


    private CartDTO mapToDTO(Cart cart) {
        CartDTO cartDTO = new CartDTO();
        cartDTO.setCartId(cart.getCartId());
        cartDTO.setUserId(cart.getUser().getUserId());
        cartDTO.setProductSizeId(cart.getProductSize().getSizeId());
        Hibernate.initialize(cart.getProductSize().getProduct());
        cartDTO.setProductName(cart.getProductSize().getProduct().getProductName());
        cartDTO.setSize(cart.getProductSize().getSize());
        cartDTO.setQuantity(cart.getQuantity());
        cartDTO.setAddedAt(cart.getAddedAt());
        return cartDTO;
    }
}