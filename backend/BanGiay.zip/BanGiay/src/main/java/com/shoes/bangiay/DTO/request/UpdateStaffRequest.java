package com.shoes.bangiay.DTO.request;

import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
public class UpdateStaffRequest {
    private String position;
    private LocalDate hireDate;
    private BigDecimal salary;
}