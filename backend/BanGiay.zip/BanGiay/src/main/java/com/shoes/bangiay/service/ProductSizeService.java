package com.shoes.bangiay.service;

import com.shoes.bangiay.DTO.response.ProductSizeDTO;

import java.util.List;

public interface ProductSizeService {
    List<ProductSizeDTO> getProductSizesByProductId(Integer productId);
}