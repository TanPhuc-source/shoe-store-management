package com.shoes.bangiay.DTO.request;

import com.shoes.bangiay.enums.ProductStatus;
import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

@Data
public class CreateProductRequest {
    private String productName;
    private String description;
    private BigDecimal price;
    private String imageUrl;
    private String status;
    private Integer categoryId;
    private Integer brandId;
    private List<ProductSizeRequest> sizes;

    @Data
    public static class ProductSizeRequest {
        private String size;
        private Integer quantity;
    }
}
