package com.shoes.bangiay.service.impl;

import com.shoes.bangiay.DTO.request.CreateProductRequest;
import com.shoes.bangiay.DTO.response.ProductDTO;
import com.shoes.bangiay.entity.Brand;
import com.shoes.bangiay.entity.Category;
import com.shoes.bangiay.entity.Product;
import com.shoes.bangiay.entity.ProductSize;
import com.shoes.bangiay.enums.ProductStatus;
import com.shoes.bangiay.repository.BrandRepository;
import com.shoes.bangiay.repository.CategoryRepository;
import com.shoes.bangiay.repository.ProductRepository;
import com.shoes.bangiay.repository.ProductSizeRepository;
import com.shoes.bangiay.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    private ProductRepository productRepository;


    @Autowired
    private CategoryRepository categoryRepository;

    @Autowired
    private BrandRepository brandRepository;

    @Autowired
    private ProductSizeRepository productSizeRepository;

    @Override
    public ProductDTO createProduct(CreateProductRequest request) {
        Category category = categoryRepository.findById(request.getCategoryId())
                .orElseThrow(() -> new RuntimeException("Category not found"));
        Brand brand = brandRepository.findById(request.getBrandId())
                .orElseThrow(() -> new RuntimeException("Brand not found"));

        Product product = new Product();
        product.setProductName(request.getProductName());
        product.setDescription(request.getDescription());
        product.setPrice(request.getPrice());
        product.setImageUrl(request.getImageUrl());
        product.setStatus(ProductStatus.valueOf(request.getStatus().toUpperCase()));
        product.setCategory(category);
        product.setBrand(brand);

        if (request.getSizes() != null) {
            List<ProductSize> sizes = request.getSizes().stream().map(sizeRequest -> {
                ProductSize productSize = new ProductSize();
                productSize.setProduct(product);
                productSize.setSize(sizeRequest.getSize());
                productSize.setQuantity(sizeRequest.getQuantity());
                return productSize;
            }).collect(Collectors.toList());
            product.setProductSizes(sizes);
        }

        final Product savedProduct = productRepository.save(product);
        // Tải lại product với category và brand để mapToProductDTO không gặp lỗi
        Product productWithDetails = productRepository.findByIdWithCategoryAndBrand(savedProduct.getProductId())
                .orElseThrow(() -> new RuntimeException("Product not found after saving"));
        return mapToProductDTO(productWithDetails);
    }

    @Override
    public Page<ProductDTO> getAllProducts(String search, Integer categoryId, Integer brandId, Pageable pageable) {
        // Hiện tại chưa dùng search, categoryId, brandId - chỉ lấy tất cả sản phẩm
        Page<Product> products = productRepository.findAllWithCategoryAndBrand(pageable);
        return products.map(this::mapToProductDTO);
    }

    @Override
    public ProductDTO getProductById(Integer productId) {
        Product product = productRepository.findByIdWithCategoryAndBrand(productId)
                .orElseThrow(() -> new RuntimeException("Product not found"));
        return mapToProductDTO(product);
    }

    @Override
    public ProductDTO updateProduct(Integer productId, CreateProductRequest request) {
        Product product = productRepository.findByIdWithCategoryAndBrand(productId)
                .orElseThrow(() -> new RuntimeException("Product not found"));

        Category category = categoryRepository.findById(request.getCategoryId())
                .orElseThrow(() -> new RuntimeException("Category not found"));
        Brand brand = brandRepository.findById(request.getBrandId())
                .orElseThrow(() -> new RuntimeException("Brand not found"));

        product.setProductName(request.getProductName());
        product.setDescription(request.getDescription());
        product.setPrice(request.getPrice());
        product.setImageUrl(request.getImageUrl());
        product.setStatus(ProductStatus.valueOf(request.getStatus().toUpperCase()));
        product.setCategory(category);
        product.setBrand(brand);

        productSizeRepository.deleteAll(product.getProductSizes());
        if (request.getSizes() != null) {
            final Product finalProduct = product;
            List<ProductSize> sizes = request.getSizes().stream().map(sizeRequest -> {
                ProductSize productSize = new ProductSize();
                productSize.setProduct(finalProduct);
                productSize.setSize(sizeRequest.getSize());
                productSize.setQuantity(sizeRequest.getQuantity());
                return productSize;
            }).collect(Collectors.toList());
            productSizeRepository.saveAll(sizes);
            product.setProductSizes(sizes);
        }

        final Product updatedProduct = productRepository.save(product);
        // Tải lại product với category và brand để mapToProductDTO không gặp lỗi
        Product productWithDetails = productRepository.findByIdWithCategoryAndBrand(updatedProduct.getProductId())
                .orElseThrow(() -> new RuntimeException("Product not found after updating"));
        return mapToProductDTO(productWithDetails);
    }

    @Override
    public void deleteProduct(Integer productId) {
        Product product = productRepository.findByIdWithCategoryAndBrand(productId)
                .orElseThrow(() -> new RuntimeException("Product not found"));
        productRepository.delete(product);
    }

    private ProductDTO mapToProductDTO(Product product) {
        ProductDTO productDTO = new ProductDTO();
        productDTO.setProductId(product.getProductId());
        productDTO.setProductName(product.getProductName());
        productDTO.setDescription(product.getDescription());
        productDTO.setPrice(product.getPrice());
        productDTO.setImageUrl(product.getImageUrl());
        productDTO.setStatus(product.getStatus().toString());
        productDTO.setCategoryId(product.getCategory().getCategoryId());
        productDTO.setCategoryName(product.getCategory().getCategoryName());
        productDTO.setBrandId(product.getBrand().getBrandId());
        productDTO.setBrandName(product.getBrand().getBrandName());
        

        return productDTO;
    }
}