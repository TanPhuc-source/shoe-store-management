package com.shoes.bangiay.controller;

import com.shoes.bangiay.DTO.request.CreateStaffRequest;
import com.shoes.bangiay.DTO.request.UpdateStaffRequest;
import com.shoes.bangiay.DTO.response.StaffDTO;
import com.shoes.bangiay.service.StaffService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/admin")
public class StaffController {
    @Autowired
    private StaffService staffService;

    // POST /api/admin/staff
    @PostMapping("/staff")
    public ResponseEntity<StaffDTO> createStaff(@RequestBody CreateStaffRequest request) {
        StaffDTO createdStaff = staffService.createStaff(request);
        return new ResponseEntity<>(createdStaff, HttpStatus.CREATED);
    }

    // GET /api/admin/staff
    @GetMapping("/staff")
    public ResponseEntity<Page<StaffDTO>> getAllStaff(Pageable pageable) {
        Page<StaffDTO> staff = staffService.getAllStaff(pageable);
        return new ResponseEntity<>(staff, HttpStatus.OK);
    }

    // PUT /api/admin/staff/:staff_id
    @PutMapping("/staff/{staffId}")
    public ResponseEntity<StaffDTO> updateStaff(@PathVariable Integer staffId, @RequestBody UpdateStaffRequest request) {
        StaffDTO updatedStaff = staffService.updateStaff(staffId, request);
        return new ResponseEntity<>(updatedStaff, HttpStatus.OK);
    }

    // DELETE /api/admin/staff/:staff_id
    @DeleteMapping("/staff/{staffId}")
    public ResponseEntity<Void> deleteStaff(@PathVariable Integer staffId) {
        staffService.deleteStaff(staffId);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}