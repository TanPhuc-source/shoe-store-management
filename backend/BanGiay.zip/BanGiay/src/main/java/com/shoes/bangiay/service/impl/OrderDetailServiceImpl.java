package com.shoes.bangiay.service.impl;

import com.shoes.bangiay.DTO.response.OrderDetailDTO;
import com.shoes.bangiay.service.OrderDetailService;

import com.shoes.bangiay.entity.OrderDetail;
import com.shoes.bangiay.entity.ProductSize;
import com.shoes.bangiay.repository.OrderDetailRepository;
import com.shoes.bangiay.service.OrderDetailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class OrderDetailServiceImpl implements OrderDetailService {
    @Autowired
    private OrderDetailRepository orderDetailRepository;

    @Override
    public List<OrderDetailDTO> getAllOrderDetails() {
        return orderDetailRepository.findAllWithDetails().stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public OrderDetailDTO getOrderDetailById(Integer id) {
        OrderDetail orderDetail = orderDetailRepository.findByIdWithDetails(id)
                .orElseThrow(() -> new RuntimeException("Order detail not found"));
        return mapToDTO(orderDetail);
    }

    @Override
    public OrderDetailDTO updateOrderDetail(Integer id, OrderDetailDTO request) {
        OrderDetail orderDetail = orderDetailRepository.findByIdWithDetails(id)
                .orElseThrow(() -> new RuntimeException("Order detail not found"));

        orderDetail.setQuantity(request.getQuantity());
        orderDetail.setPrice(request.getPrice());

        OrderDetail updatedOrderDetail = orderDetailRepository.save(orderDetail);

        // Tải lại dữ liệu với đầy đủ thông tin liên quan
        OrderDetail reloadedOrderDetail = orderDetailRepository.findByIdWithDetails(updatedOrderDetail.getDetailId())
                .orElseThrow(() -> new RuntimeException("Order detail not found after update"));

        return mapToDTO(reloadedOrderDetail);
    }

    @Override
    public void deleteOrderDetail(Integer id) {
        OrderDetail orderDetail = orderDetailRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Order detail not found"));
        orderDetailRepository.delete(orderDetail);
    }

    private OrderDetailDTO mapToDTO(OrderDetail orderDetail) {
        OrderDetailDTO dto = new OrderDetailDTO();
        dto.setOrderDetailId(orderDetail.getDetailId());
        dto.setOrderId(orderDetail.getOrder().getOrderId());
        dto.setProductSizeId(orderDetail.getProductSize().getSizeId());
        ProductSize productSize = orderDetail.getProductSize();
        dto.setProductName(productSize.getProduct().getProductName());
        dto.setSize(productSize.getSize());
        dto.setQuantity(orderDetail.getQuantity());
        dto.setPrice(orderDetail.getPrice());
        return dto;
    }
}
