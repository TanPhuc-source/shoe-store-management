package com.shoes.bangiay.DTO.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.shoes.bangiay.enums.OrderStatus;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Data
public class OrderDTO {
    private Integer orderId;
    private Integer userId;
    private String username;
    private LocalDateTime orderDate;
    private BigDecimal totalAmount;
    private OrderStatus status;
    private List<OrderDetailDTO> orderDetails;
    @JsonProperty("shippingAddress") // Đảm bảo ánh xạ đúng với JSON
    private String shippingAddress;

    @Data
    public static class OrderDetailDTO {
        private Integer orderDetailId;
        private Integer productSizeId;
        private String productName;
        private String size;
        private Integer quantity;
        private BigDecimal price;
    }
}
