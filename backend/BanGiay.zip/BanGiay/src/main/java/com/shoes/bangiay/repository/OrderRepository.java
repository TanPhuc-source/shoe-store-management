package com.shoes.bangiay.repository;

import com.shoes.bangiay.entity.Order;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface OrderRepository extends JpaRepository<Order, Integer> {
    // Lấy danh sách đơn hàng của một người dùng
    @Query("SELECT o FROM Order o JOIN FETCH o.user JOIN FETCH o.orderDetails od JOIN FETCH od.productSize ps JOIN FETCH ps.product WHERE o.user.userId = :userId")
    List<Order> findByUserId(Integer userId);

    // Lấy chi tiết một đơn hàng theo orderId
    @Query("SELECT o FROM Order o JOIN FETCH o.user JOIN FETCH o.orderDetails od JOIN FETCH od.productSize ps JOIN FETCH ps.product WHERE o.orderId = :orderId")
    Optional<Order> findByIdWithDetails(Integer orderId);

    // Lấy danh sách tất cả đơn hàng (phân trang, cho admin)
    @Query("SELECT o FROM Order o JOIN FETCH o.user JOIN FETCH o.orderDetails od JOIN FETCH od.productSize ps JOIN FETCH ps.product")
    Page<Order> findAllWithDetails(Pageable pageable);
}
