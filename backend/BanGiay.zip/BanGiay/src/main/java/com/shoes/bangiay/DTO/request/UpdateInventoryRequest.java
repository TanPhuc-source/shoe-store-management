package com.shoes.bangiay.DTO.request;

import lombok.Data;

@Data
public class UpdateInventoryRequest {
    private Integer quantity;
}