package com.shoes.bangiay.controller;

import com.shoes.bangiay.DTO.response.BrandDTO;
import com.shoes.bangiay.service.BrandService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class BrandController {
    @Autowired
    private BrandService brandService;

    // GET /api/brands
    @GetMapping("/brands")
    public ResponseEntity<List<BrandDTO>> getAllBrands() {
        List<BrandDTO> brands = brandService.getAllBrands();
        return new ResponseEntity<>(brands, HttpStatus.OK);
    }

    // GET /api/brands/:brand_id
    @GetMapping("/brands/{brandId}")
    public ResponseEntity<BrandDTO> getBrandById(@PathVariable Integer brandId) {
        BrandDTO brand = brandService.getBrandById(brandId);
        return new ResponseEntity<>(brand, HttpStatus.OK);
    }

    // GET /api/admin/brands
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/admin/brands")
    public ResponseEntity<Page<BrandDTO>> getAllBrandsForAdmin(Pageable pageable) {
        Page<BrandDTO> brands = brandService.getAllBrandsForAdmin(pageable);
        return new ResponseEntity<>(brands, HttpStatus.OK);
    }

    // GET /api/admin/brands/:brand_id
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/admin/brands/{brandId}")
    public ResponseEntity<BrandDTO> getBrandByIdForAdmin(@PathVariable Integer brandId) {
        BrandDTO brand = brandService.getBrandById(brandId);
        return new ResponseEntity<>(brand, HttpStatus.OK);
    }

    // POST /api/admin/brands
    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/admin/brands")
    public ResponseEntity<BrandDTO> createBrand(@RequestBody BrandDTO request) {
        BrandDTO createdBrand = brandService.createBrand(request);
        return new ResponseEntity<>(createdBrand, HttpStatus.CREATED);
    }

    // PUT /api/admin/brands/:brand_id
    @PreAuthorize("hasRole('ADMIN')")
    @PutMapping("/admin/brands/{brandId}")
    public ResponseEntity<BrandDTO> updateBrand(
            @PathVariable Integer brandId,
            @RequestBody BrandDTO request) {
        BrandDTO updatedBrand = brandService.updateBrand(brandId, request);
        return new ResponseEntity<>(updatedBrand, HttpStatus.OK);
    }

    // DELETE /api/admin/brands/:brand_id
    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/admin/brands/{brandId}")
    public ResponseEntity<Void> deleteBrand(@PathVariable Integer brandId) {
        brandService.deleteBrand(brandId);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}