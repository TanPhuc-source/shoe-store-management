package com.shoes.bangiay.DTO.response;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class OrderDetailDTO {
    private Integer orderDetailId;
    private Integer orderId;
    private Integer productSizeId;
    private String productName;
    private String size;
    private Integer quantity;
    private BigDecimal price;
}
