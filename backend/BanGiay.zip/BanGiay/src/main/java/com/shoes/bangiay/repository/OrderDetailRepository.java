package com.shoes.bangiay.repository;

import com.shoes.bangiay.entity.OrderDetail;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface OrderDetailRepository extends JpaRepository<OrderDetail, Integer> {
    // Lấy chi tiết đơn hàng theo ID, kèm thông tin liên quan
    @Query("SELECT od FROM OrderDetail od " +
            "JOIN FETCH od.order o " +
            "JOIN FETCH od.productSize ps " +
            "JOIN FETCH ps.product p " +
            "WHERE od.detailId = :id")
    Optional<OrderDetail> findByIdWithDetails(@Param("id") Integer id);

    // Lấy tất cả chi tiết đơn hàng, kèm thông tin liên quan
    @Query("SELECT od FROM OrderDetail od " +
            "JOIN FETCH od.order o " +
            "JOIN FETCH od.productSize ps " +
            "JOIN FETCH ps.product p")
    List<OrderDetail> findAllWithDetails();
}
