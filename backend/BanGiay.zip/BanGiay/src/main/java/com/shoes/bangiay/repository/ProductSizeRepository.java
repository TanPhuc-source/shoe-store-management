package com.shoes.bangiay.repository;

import com.shoes.bangiay.entity.ProductSize;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ProductSizeRepository extends JpaRepository<ProductSize, Integer>{
    @Query("SELECT ps FROM ProductSize ps JOIN FETCH ps.product WHERE ps.sizeId = :sizeId")
    Optional<ProductSize> findByIdWithProduct(Integer sizeId);
}
