package com.shoes.bangiay.entity;

import com.shoes.bangiay.enums.OrderStatus;
import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;

@Converter(autoApply = false) // Áp dụng tự động cho tất cả các thuộc tính kiểu OrderStatus
public class OrderStatusConverter implements AttributeConverter<OrderStatus, String> {

    @Override
    public String convertToDatabaseColumn(OrderStatus attribute) {
        if (attribute == null) return null;
        return attribute.name().toLowerCase(); // Lưu vào cơ sở dữ liệu dưới dạng chữ thường
    }

    @Override
    public OrderStatus convertToEntityAttribute(String dbData) {
        System.out.println("Converting DB data to OrderStatus: " + dbData);
        if (dbData == null) return null;
        try {
            return OrderStatus.valueOf(dbData.toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Unknown OrderStatus value: " + dbData, e);
        }
    }
}