package com.shoes.bangiay.DTO.request;

import lombok.Data;

@Data
public class CreateBrandRequest {
    private Integer brandId;
    private String brandName;
    private String description;
}
