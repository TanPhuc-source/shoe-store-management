package com.shoes.bangiay.DTO.response;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class CartDTO {
    private Integer cartId;
    private Integer userId;
    private Integer productSizeId;
    private String productName;
    private String size;
    private Integer quantity;
    private LocalDateTime addedAt;
}