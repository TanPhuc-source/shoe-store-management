package com.shoes.bangiay.DTO.response;

import lombok.Data;

@Data
public class BrandDTO {
    private Integer brandId;
    private String brandName;
    private String description;
}
