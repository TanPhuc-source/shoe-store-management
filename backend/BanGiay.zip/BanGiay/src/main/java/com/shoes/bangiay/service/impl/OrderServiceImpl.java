package com.shoes.bangiay.service.impl;

import com.shoes.bangiay.DTO.request.CreateOrderRequest;
import com.shoes.bangiay.DTO.request.UpdateOrderRequest;
import com.shoes.bangiay.DTO.response.OrderDTO;
import com.shoes.bangiay.entity.Order;
import com.shoes.bangiay.entity.OrderDetail;
import com.shoes.bangiay.entity.ProductSize;
import com.shoes.bangiay.entity.User;
import com.shoes.bangiay.enums.OrderStatus;
import com.shoes.bangiay.repository.OrderRepository;
import com.shoes.bangiay.repository.ProductSizeRepository;
import com.shoes.bangiay.repository.UserRepository;
import com.shoes.bangiay.service.OrderService;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class OrderServiceImpl implements OrderService {
    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ProductSizeRepository productSizeRepository;

    @Override
    @Transactional
    public OrderDTO createOrder(CreateOrderRequest request) {
        // Kiểm tra người dùng hiện tại
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !authentication.isAuthenticated()) {
            throw new RuntimeException("User not authenticated");
        }
        String username = authentication.getName();
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("User not found: " + username));

        // Kiểm tra userId trong request
        if (!user.getUserId().equals(request.getUserId())) {
            throw new RuntimeException("You do not have permission to create this order");
        }

        // Kiểm tra shippingAddress
        if (request.getShippingAddress() == null || request.getShippingAddress().trim().isEmpty()) {
            throw new IllegalArgumentException("Shipping address is required");
        }

        // Kiểm tra danh sách chi tiết đơn hàng
        if (request.getOrderDetails() == null || request.getOrderDetails().isEmpty()) {
            throw new IllegalArgumentException("Order details cannot be empty");
        }

        Order order = new Order();
        order.setUser(user);
        order.setOrderDate(LocalDateTime.now());
        order.setStatus(OrderStatus.PENDING); // Sử dụng enum
        order.setShippingAddress(request.getShippingAddress());

        // Tạo chi tiết đơn hàng và kiểm tra tồn kho
        List<OrderDetail> orderDetails = request.getOrderDetails().stream().map(detailRequest -> {
            ProductSize productSize = productSizeRepository.findByIdWithProduct(detailRequest.getProductSizeId())
                    .orElseThrow(() -> new RuntimeException("ProductSize not found: " + detailRequest.getProductSizeId()));

            // Kiểm tra tồn kho
            if (productSize.getQuantity() < detailRequest.getQuantity()) {
                throw new RuntimeException("Insufficient stock for product size ID: " + productSize.getSizeId());
            }

            OrderDetail orderDetail = new OrderDetail();
            orderDetail.setOrder(order);
            orderDetail.setProductSize(productSize);
            orderDetail.setQuantity(detailRequest.getQuantity());
            orderDetail.setPrice(productSize.getProduct().getPrice());

            // Giảm tồn kho
            productSize.setQuantity(productSize.getQuantity() - detailRequest.getQuantity());
            productSizeRepository.save(productSize);

            return orderDetail;
        }).collect(Collectors.toList());

        order.setOrderDetails(orderDetails);

        // Tính tổng tiền
        BigDecimal totalAmount = orderDetails.stream()
                .map(od -> od.getPrice().multiply(BigDecimal.valueOf(od.getQuantity())))
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        order.setTotalAmount(totalAmount);

        Order savedOrder = orderRepository.save(order);
        Order orderWithDetails = orderRepository.findByIdWithDetails(savedOrder.getOrderId())
                .orElseThrow(() -> new RuntimeException("Order not found after saving: " + savedOrder.getOrderId()));
        return mapToDTO(orderWithDetails);
    }

    @Override
    public List<OrderDTO> getOrdersByUserId() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !authentication.isAuthenticated()) {
            throw new RuntimeException("User not authenticated");
        }

        String username = authentication.getName();
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("User not found: " + username));

        Integer userId = user.getUserId();
        return orderRepository.findByUserId(userId).stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public OrderDTO getOrderById(Integer orderId) {
        Order order = orderRepository.findByIdWithDetails(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found: " + orderId));
        return mapToDTO(order);
    }

    @Override
    @Transactional
    public OrderDTO updateOrder(Integer orderId, UpdateOrderRequest request) {
        Order order = orderRepository.findByIdWithDetails(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found: " + orderId));

        // Kiểm tra quyền
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !authentication.isAuthenticated()) {
            throw new RuntimeException("User not authenticated");
        }
        String username = authentication.getName();
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("User not found: " + username));

        if (!user.getUserId().equals(order.getUser().getUserId()) && !user.getRole().equals("ADMIN")) {
            throw new RuntimeException("You do not have permission to update this order");
        }

        // Kiểm tra trạng thái hợp lệ
        if (request.getStatus() != null) {
            OrderStatus currentStatus = order.getStatus();
            OrderStatus newStatus = request.getStatus();
            if (!isValidStatusTransition(currentStatus, newStatus)) {
                throw new RuntimeException("Invalid status transition from " + currentStatus + " to " + newStatus);
            }

            // Nếu hủy đơn hàng, hoàn trả tồn kho
            boolean isCancelling = newStatus == OrderStatus.CANCELLED && currentStatus != OrderStatus.CANCELLED;
            if (isCancelling) {
                for (OrderDetail detail : order.getOrderDetails()) {
                    ProductSize productSize = detail.getProductSize();
                    productSize.setQuantity(productSize.getQuantity() + detail.getQuantity());
                    productSizeRepository.save(productSize);
                }
            }
            order.setStatus(newStatus); // Sử dụng enum
        }

        // Cập nhật địa chỉ giao hàng
        if (request.getShippingAddress() != null && !request.getShippingAddress().trim().isEmpty()) {
            order.setShippingAddress(request.getShippingAddress());
        }

        Order updatedOrder = orderRepository.save(order);
        Order reloadedOrder = orderRepository.findByIdWithDetails(updatedOrder.getOrderId())
                .orElseThrow(() -> new RuntimeException("Order not found after update: " + updatedOrder.getOrderId()));
        return mapToDTO(reloadedOrder);
    }

    @Override
    public Page<OrderDTO> getAllOrdersForAdmin(Pageable pageable) {
        return orderRepository.findAllWithDetails(pageable)
                .map(this::mapToDTO);
    }

    @Override
    @Transactional
    public void deleteOrder(Integer orderId) {
        Order order = orderRepository.findByIdWithDetails(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found: " + orderId));

        // Kiểm tra quyền
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !authentication.isAuthenticated()) {
            throw new RuntimeException("User not authenticated");
        }
        String username = authentication.getName();
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("User not found: " + username));

        if (!user.getUserId().equals(order.getUser().getUserId()) && !user.getRole().equals("ADMIN")) {
            throw new RuntimeException("You do not have permission to delete this order");
        }

        // Hoàn trả tồn kho
        if (order.getStatus() != OrderStatus.CANCELLED) {
            for (OrderDetail detail : order.getOrderDetails()) {
                ProductSize productSize = detail.getProductSize();
                productSize.setQuantity(productSize.getQuantity() + detail.getQuantity());
                productSizeRepository.save(productSize);
            }
        }

        orderRepository.delete(order);
    }

    private boolean isValidStatusTransition(OrderStatus current, OrderStatus next) {
        switch (current) {
            case PENDING:
                return next == OrderStatus.SHIPPED || next == OrderStatus.CANCELLED;
            case SHIPPED:
                return next == OrderStatus.DELIVERED || next == OrderStatus.CANCELLED;
            case DELIVERED:
            case CANCELLED:
                return false; // Không cho phép chuyển từ DELIVERED hoặc CANCELLED
            default:
                return false;
        }
    }

    private OrderDTO mapToDTO(Order order) {
        OrderDTO dto = new OrderDTO();
        dto.setOrderId(order.getOrderId());
        dto.setUserId(order.getUser().getUserId());
        dto.setUsername(order.getUser().getUsername());
        dto.setOrderDate(order.getOrderDate());
        dto.setTotalAmount(order.getTotalAmount());
        dto.setStatus(order.getStatus()); // Sử dụng enum trực tiếp
        dto.setShippingAddress(order.getShippingAddress());

        if (order.getOrderDetails() != null) {
            List<OrderDTO.OrderDetailDTO> detailDTOs = order.getOrderDetails().stream()
                    .map(detail -> {
                        OrderDTO.OrderDetailDTO detailDTO = new OrderDTO.OrderDetailDTO();
                        detailDTO.setOrderDetailId(detail.getDetailId());
                        detailDTO.setProductSizeId(detail.getProductSize().getSizeId());
                        detailDTO.setProductName(detail.getProductSize().getProduct().getProductName());
                        detailDTO.setSize(detail.getProductSize().getSize());
                        detailDTO.setQuantity(detail.getQuantity());
                        detailDTO.setPrice(detail.getPrice());
                        return detailDTO;
                    }).collect(Collectors.toList());
            dto.setOrderDetails(detailDTOs);
        }

        return dto;
    }
}