package com.shoes.bangiay.service;

import com.shoes.bangiay.DTO.request.CreateInventoryRequest;
import com.shoes.bangiay.DTO.request.UpdateInventoryRequest;
import com.shoes.bangiay.DTO.response.InventoryDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface InventoryService {
    InventoryDTO createInventory(CreateInventoryRequest request);
    Page<InventoryDTO> getAllInventory(Pageable pageable);
    InventoryDTO updateInventory(Integer inventoryId, UpdateInventoryRequest request);
    void deleteInventory(Integer inventoryId);
}