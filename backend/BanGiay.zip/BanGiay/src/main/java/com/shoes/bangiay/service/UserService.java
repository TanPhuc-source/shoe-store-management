package com.shoes.bangiay.service;

import com.shoes.bangiay.DTO.request.*;
import com.shoes.bangiay.DTO.response.UserResponse;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface UserService {
    UserResponse register(RegisterRequest request);
    UserResponse login(LoginRequest request);
    UserResponse getProfile(Integer userId);
    UserResponse updateProfile(Integer userId, UpdateProfileRequest request);
    void changePassword(Integer userId, ChangePasswordRequest request);
    UserResponse createUser(CreateUserRequest request);
    Page<UserResponse> getAllUsers(String role, Pageable pageable);
    UserResponse updateUser(Integer userId, CreateUserRequest request);
    void deleteUser(Integer userId);
}
