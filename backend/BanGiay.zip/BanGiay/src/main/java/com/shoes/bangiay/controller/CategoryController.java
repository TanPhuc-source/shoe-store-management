package com.shoes.bangiay.controller;

import com.shoes.bangiay.DTO.response.CategoryDTO;
import com.shoes.bangiay.service.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class CategoryController {
    @Autowired
    private CategoryService categoryService;

    // GET /api/categories
    @GetMapping("/categories")
    public ResponseEntity<List<CategoryDTO>> getAllCategories() {
        List<CategoryDTO> categories = categoryService.getAllCategories();
        return new ResponseEntity<>(categories, HttpStatus.OK);
    }

    // GET /api/categories/:category_id
    @GetMapping("/categories/{categoryId}")
    public ResponseEntity<CategoryDTO> getCategoryById(@PathVariable Integer categoryId) {
        CategoryDTO category = categoryService.getCategoryById(categoryId);
        return new ResponseEntity<>(category, HttpStatus.OK);
    }

    // GET /api/admin/categories
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/admin/categories")
    public ResponseEntity<Page<CategoryDTO>> getAllCategoriesForAdmin(Pageable pageable) {
        Page<CategoryDTO> categories = categoryService.getAllCategoriesForAdmin(pageable);
        return new ResponseEntity<>(categories, HttpStatus.OK);
    }

    // GET /api/admin/categories/:category_id
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/admin/categories/{categoryId}")
    public ResponseEntity<CategoryDTO> getCategoryByIdForAdmin(@PathVariable Integer categoryId) {
        CategoryDTO category = categoryService.getCategoryById(categoryId);
        return new ResponseEntity<>(category, HttpStatus.OK);
    }

    // POST /api/admin/categories
    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/admin/categories")
    public ResponseEntity<CategoryDTO> createCategory(@RequestBody CategoryDTO request) {
        CategoryDTO createdCategory = categoryService.createCategory(request);
        return new ResponseEntity<>(createdCategory, HttpStatus.CREATED);
    }

    // PUT /api/admin/categories/:category_id
    @PreAuthorize("hasRole('ADMIN')")
    @PutMapping("/admin/categories/{categoryId}")
    public ResponseEntity<CategoryDTO> updateCategory(
            @PathVariable Integer categoryId,
            @RequestBody CategoryDTO request) {
        CategoryDTO updatedCategory = categoryService.updateCategory(categoryId, request);
        return new ResponseEntity<>(updatedCategory, HttpStatus.OK);
    }

    // DELETE /api/admin/categories/:category_id
    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/admin/categories/{categoryId}")
    public ResponseEntity<Void> deleteCategory(@PathVariable Integer categoryId) {
        categoryService.deleteCategory(categoryId);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}