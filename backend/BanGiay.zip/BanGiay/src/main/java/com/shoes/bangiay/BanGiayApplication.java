package com.shoes.bangiay;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BanGiayApplication {

    public static void main(String[] args) {
        SpringApplication.run(BanGiayApplication.class, args);
    }

}
