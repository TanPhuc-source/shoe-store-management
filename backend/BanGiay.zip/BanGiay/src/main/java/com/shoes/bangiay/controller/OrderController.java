package com.shoes.bangiay.controller;

import com.shoes.bangiay.DTO.request.CreateOrderRequest;
import com.shoes.bangiay.DTO.request.UpdateOrderRequest;
import com.shoes.bangiay.DTO.response.OrderDTO;
import com.shoes.bangiay.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class OrderController {
    @Autowired
    private OrderService orderService;

    // POST /api/orders
    @PostMapping("/orders")
    public ResponseEntity<OrderDTO> createOrder(@RequestBody CreateOrderRequest request) {
        OrderDTO createdOrder = orderService.createOrder(request);
        return new ResponseEntity<>(createdOrder, HttpStatus.CREATED);
    }

    // GET /api/orders
    @GetMapping("/orders")
    public ResponseEntity<List<OrderDTO>> getOrdersByUserId() {
        List<OrderDTO> orders = orderService.getOrdersByUserId();
        return new ResponseEntity<>(orders, HttpStatus.OK);
    }

    // GET /api/orders/:order_id
    @GetMapping("/orders/{orderId}")
    public ResponseEntity<OrderDTO> getOrderById(@PathVariable Integer orderId) {
        OrderDTO order = orderService.getOrderById(orderId);
        return new ResponseEntity<>(order, HttpStatus.OK);
    }

    // PUT /api/orders/:order_id
    @PutMapping("/orders/{orderId}")
    public ResponseEntity<OrderDTO> cancelOrder(@PathVariable Integer orderId, @RequestBody UpdateOrderRequest request) {
        OrderDTO updatedOrder = orderService.updateOrder(orderId, request);
        return new ResponseEntity<>(updatedOrder, HttpStatus.OK);
    }

    // GET /api/admin/orders
    @GetMapping("/admin/orders")
    public ResponseEntity<Page<OrderDTO>> getAllOrdersForAdmin(Pageable pageable) {
        Page<OrderDTO> orders = orderService.getAllOrdersForAdmin(pageable);
        return new ResponseEntity<>(orders, HttpStatus.OK);
    }

    // GET /api/admin/orders/:order_id
    @GetMapping("/admin/orders/{orderId}")
    public ResponseEntity<OrderDTO> getOrderByIdForAdmin(@PathVariable Integer orderId) {
        OrderDTO order = orderService.getOrderById(orderId);
        return new ResponseEntity<>(order, HttpStatus.OK);
    }

    // PUT /api/admin/orders/:order_id
    @PutMapping("/admin/orders/{orderId}")
    public ResponseEntity<OrderDTO> updateOrderStatusForAdmin(
            @PathVariable Integer orderId,
            @RequestBody UpdateOrderRequest request) {
        OrderDTO updatedOrder = orderService.updateOrder(orderId, request);
        return new ResponseEntity<>(updatedOrder, HttpStatus.OK);
    }

    // DELETE /api/orders/:order_id
    @DeleteMapping("/orders/{orderId}")
    public ResponseEntity<Void> deleteOrder(@PathVariable Integer orderId) {
        orderService.deleteOrder(orderId);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}