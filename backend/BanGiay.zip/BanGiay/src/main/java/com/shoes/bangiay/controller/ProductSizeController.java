package com.shoes.bangiay.controller;

import com.shoes.bangiay.DTO.response.ProductSizeDTO;
import com.shoes.bangiay.service.ProductSizeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class ProductSizeController {
    @Autowired
    private ProductSizeService productSizeService;

    // GET /api/product-sizes
    @GetMapping("/product-sizes")
    public ResponseEntity<List<ProductSizeDTO>> getProductSizesByProductId(@RequestParam Integer productId) {
        List<ProductSizeDTO> sizes = productSizeService.getProductSizesByProductId(productId);
        return new ResponseEntity<>(sizes, HttpStatus.OK);
    }

    // GET /api/admin/products/:product_id/sizes
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/admin/products/{productId}/sizes")
    public ResponseEntity<List<ProductSizeDTO>> getProductSizesByProductIdForAdmin(@PathVariable Integer productId) {
        List<ProductSizeDTO> sizes = productSizeService.getProductSizesByProductId(productId);
        return new ResponseEntity<>(sizes, HttpStatus.OK);
    }
}