package com.shoes.bangiay.DTO.request;

import com.shoes.bangiay.entity.Order;
import com.shoes.bangiay.entity.ProductSize;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class OrderDetailRequest {
    private ProductSize productSize;
    private Order order;
    private BigDecimal price;
    private Integer quantity;
    private Integer detailId;

}
