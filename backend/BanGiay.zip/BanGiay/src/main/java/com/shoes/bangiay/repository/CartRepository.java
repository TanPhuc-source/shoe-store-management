package com.shoes.bangiay.repository;

import com.shoes.bangiay.entity.Cart;
import com.shoes.bangiay.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface CartRepository extends JpaRepository<Cart, Integer> {
    @Query("SELECT c FROM Cart c JOIN FETCH c.productSize ps JOIN FETCH ps.product p WHERE c.user.userId = :userId")
    List<Cart> findByUserId(@Param("userId") Integer userId);

    @Modifying
    @Query("DELETE FROM Cart c WHERE c.user = :user")
    void deleteByUser(User user);
}