package com.shoes.bangiay.service.impl;

import com.shoes.bangiay.DTO.request.CreateInventoryRequest;
import com.shoes.bangiay.DTO.request.UpdateInventoryRequest;
import com.shoes.bangiay.DTO.response.InventoryDTO;
import com.shoes.bangiay.entity.Inventory;
import com.shoes.bangiay.entity.Product;
import com.shoes.bangiay.entity.ProductSize;
import com.shoes.bangiay.repository.InventoryRepository;
import com.shoes.bangiay.repository.ProductRepository;
import com.shoes.bangiay.repository.ProductSizeRepository;
import com.shoes.bangiay.service.InventoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class InventoryServiceImpl implements InventoryService {
    @Autowired
    private InventoryRepository inventoryRepository;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private ProductSizeRepository productSizeRepository;

    @Override
    public InventoryDTO createInventory(CreateInventoryRequest request) {
        Product product = productRepository.findById(request.getProductId())
                .orElseThrow(() -> new RuntimeException("Product not found"));
        ProductSize productSize = productSizeRepository.findById(request.getSizeId())
                .orElseThrow(() -> new RuntimeException("Product size not found"));

        Inventory inventory = new Inventory();
        inventory.setProduct(product);
        inventory.setProductSize(productSize);
        inventory.setQuantity(request.getQuantity());
        inventory.setLastUpdated(LocalDateTime.now());

        Inventory savedInventory = inventoryRepository.save(inventory);
        return mapToDTO(savedInventory);
    }

    @Override
    public Page<InventoryDTO> getAllInventory(Pageable pageable) {
        return inventoryRepository.findAll(pageable)
                .map(this::mapToDTO);
    }

    @Override
    public InventoryDTO updateInventory(Integer inventoryId, UpdateInventoryRequest request) {
        Inventory inventory = inventoryRepository.findById(inventoryId)
                .orElseThrow(() -> new RuntimeException("Inventory not found"));

        inventory.setQuantity(request.getQuantity());
        inventory.setLastUpdated(LocalDateTime.now());

        Inventory updatedInventory = inventoryRepository.save(inventory);
        return mapToDTO(updatedInventory);
    }

    @Override
    public void deleteInventory(Integer inventoryId) {
        Inventory inventory = inventoryRepository.findById(inventoryId)
                .orElseThrow(() -> new RuntimeException("Inventory not found"));
        inventoryRepository.delete(inventory);
    }

    private InventoryDTO mapToDTO(Inventory inventory) {
        InventoryDTO dto = new InventoryDTO();
        dto.setInventoryId(inventory.getInventoryId());
        dto.setProductId(inventory.getProduct().getProductId());
        dto.setProductName(inventory.getProduct().getProductName());
        dto.setSizeId(inventory.getProductSize().getSizeId());
        dto.setSize(inventory.getProductSize().getSize());
        dto.setQuantity(inventory.getQuantity());
        dto.setLastUpdated(inventory.getLastUpdated());
        return dto;
    }
}