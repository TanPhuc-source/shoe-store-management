package com.shoes.bangiay;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class PasswordEncoderTest {
    public static void main(String[] args) {
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        String rawPassword = "admin123"; // Thay bằng mật khẩu thực tế
        String encodedPassword = encoder.encode(rawPassword);
        System.out.println(encodedPassword);
    }
}
