package com.shoes.bangiay.DTO.request;

import lombok.Data;

@Data
public class CreateInventoryRequest {
    private Integer productId;
    private Integer sizeId;
    private Integer quantity;
}