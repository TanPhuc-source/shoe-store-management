package com.shoes.bangiay.DTO.request;

import com.shoes.bangiay.enums.OrderStatus;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class UpdateOrderRequest {
    private Integer userId;
    private LocalDateTime orderDate;
    @NotBlank(message = "Shipping address cannot be empty")
    private String shippingAddress;
    private OrderStatus status; // Sử dụng enum
    private BigDecimal totalAmount;
}
