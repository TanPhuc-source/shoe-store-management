package com.shoes.bangiay.DTO.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class CreateOrderRequest {
    private Integer userId;
    @JsonProperty("shippingAddress")
    private String shippingAddress;
    private List<OrderDetailRequest> orderDetails;

    @Data
    public static class OrderDetailRequest {
        private Integer productSizeId;
        private Integer quantity;
    }
}
