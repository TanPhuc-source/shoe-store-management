package com.shoes.bangiay;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BanGiayApplicationTests {

    @Test
    void contextLoads() {
    }

}
